#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "tree.h"

#ifndef BUILDTREE_OFF
TreeNode * validation(Scanner * s);

TreeNode * buildExpressionTree(Scanner * s) {

//FILL IN

	if(s == NULL){

		return NULL;

	}

	return validation(s);
}
#endif

#ifndef POSTFIX_OFF
void makePostFix(TreeNode * t, FILE * fptr) {
	
//FILL IN

	if(t == NULL){

		return;

	}

	makePostFix(t->left, fptr);

	makePostFix(t->right, fptr);

	Token sample = t->t;

	if(sample.type != T_VAL){

		if(sample.type == T_ADD){

			fprintf(fptr, "+ ");

		}

		if(sample.type == T_SUB){

                        fprintf(fptr, "- ");

                }

		if(sample.type == T_MUL){

                        fprintf(fptr, "* ");

                }

		if(sample.type == T_DIV){

                        fprintf(fptr, "/ ");

                }

	}

	if(sample.type == T_VAL){

		fprintf(fptr, "%f ", sample.value);

	}
 
	return;

}

TreeNode * validation(Scanner * s){

	if(s == NULL){

		return NULL;

	}

	Token coin = nextToken(s);
 
	if(coin.type == T_VAL){

		return buildTreeNode(coin);

	}

	if(coin.type == T_LPAREN){

		TreeNode * ans = validation(s);

		if(ans != NULL){
		
			Token next = nextToken(s);

			if((next.type == T_ADD) || (next.type == T_SUB) || (next.type == T_MUL) || (next.type == T_DIV)){

				TreeNode * second = validation(s);

				if(second != NULL){

					Token closing = nextToken(s);

					if(closing.type == T_RPAREN){

						TreeNode * subTree = buildTreeNode(next);

						subTree->left = ans;

						subTree->right = second;
						
						return subTree;

					}

				}	
			
			}

		}

	}

	return NULL;
}


#endif
